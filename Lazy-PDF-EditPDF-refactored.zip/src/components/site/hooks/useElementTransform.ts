import { useCallback, useEffect, useMemo, useReducer, useRef } from "react";
import type { AnyElement, TextElement } from "@/lib/pdf-annotations";
import { elementScreenRect, rotateVector } from "@/lib/pdf-editor-coordinates";
import type { ResizeHandle } from "../editor-types";

const MIN_ELEMENT_SIZE = 16;

type MoveInteraction = {
  kind: "move";
  ids: string[];
  offsets: Record<string, { x: number; y: number }>;
  point: { x: number; y: number };
};

type ResizeInteraction = {
  kind: "resize";
  id: string;
  handle: ResizeHandle;
  start: { x: number; y: number; width: number; height: number };
  startRotation: number;
  startFontSize?: number;
  latestClient: { x: number; y: number };
  startClient: { x: number; y: number };
};

type RotateInteraction = {
  kind: "rotate";
  id: string;
  center: { x: number; y: number };
  startAngle: number;
  startRotation: number;
  latest: { x: number; y: number; shift: boolean };
};

export type TransformInteraction = MoveInteraction | ResizeInteraction | RotateInteraction | null;

type TransformAction =
  | { type: "beginMove"; ids: string[]; offsets: Record<string, { x: number; y: number }>; point: { x: number; y: number } }
  | { type: "beginResize"; id: string; handle: ResizeHandle; start: ResizeInteraction["start"]; startRotation: number; startFontSize?: number; startClient: { x: number; y: number } }
  | { type: "beginRotate"; id: string; center: { x: number; y: number }; startAngle: number; startRotation: number; latest: RotateInteraction["latest"] }
  | { type: "movePointer"; point: { x: number; y: number } }
  | { type: "moveClient"; client: { x: number; y: number } }
  | { type: "rotatePointer"; latest: RotateInteraction["latest"] }
  | { type: "end" };

export function transformReducer(state: TransformInteraction, action: TransformAction): TransformInteraction {
  switch (action.type) {
    case "beginMove":
      return { kind: "move", ids: action.ids, offsets: action.offsets, point: action.point };
    case "beginResize":
      return { kind: "resize", id: action.id, handle: action.handle, start: action.start, startRotation: action.startRotation, startFontSize: action.startFontSize, startClient: action.startClient, latestClient: action.startClient };
    case "beginRotate":
      return { kind: "rotate", id: action.id, center: action.center, startAngle: action.startAngle, startRotation: action.startRotation, latest: action.latest };
    case "movePointer":
      return state?.kind === "move" ? { ...state, point: action.point } : state;
    case "moveClient":
      return state?.kind === "resize" ? { ...state, latestClient: action.client } : state;
    case "rotatePointer":
      return state?.kind === "rotate" ? { ...state, latest: action.latest } : state;
    case "end":
      return null;
  }
}

function applyResizeHandle(handle: ResizeHandle, start: ResizeInteraction["start"], localDx: number, localDy: number) {
  let { x, y, width, height } = start;
  if (handle.includes("w")) { width = start.width - localDx; x = start.x + localDx; }
  if (handle.includes("e")) width = start.width + localDx;
  if (handle.includes("n")) { height = start.height - localDy; y = start.y + localDy; }
  if (handle.includes("s")) height = start.height + localDy;
  if (width < MIN_ELEMENT_SIZE) {
    if (handle.includes("w")) x -= MIN_ELEMENT_SIZE - width;
    width = MIN_ELEMENT_SIZE;
  }
  if (height < MIN_ELEMENT_SIZE) {
    if (handle.includes("n")) y -= MIN_ELEMENT_SIZE - height;
    height = MIN_ELEMENT_SIZE;
  }
  return { x, y, width, height };
}

type Options = {
  pageRotation: 0 | 90 | 180 | 270;
  pageWidth: number;
  pageHeight: number;
  scale: number;
  getLayerRect: () => DOMRect | null;
  toPagePoint: (clientX: number, clientY: number) => { x: number; y: number } | null;
  onCommitElements: (ids: Set<string>, patchFn: (element: AnyElement) => Partial<AnyElement>) => void;
};

export function useElementTransform(options: Options) {
  const [interaction, dispatch] = useReducer(transformReducer, null);
  const callbacksRef = useRef(options);
  callbacksRef.current = options;

  const beginMove = useCallback((element: AnyElement, selectedIds: Set<string>, point: { x: number; y: number }) => {
    const ids = Array.from(selectedIds);
    if (!ids.includes(element.id)) return;
    const offsets: Record<string, { x: number; y: number }> = {};
    // Element coordinates are read from the caller, so only the selected item
    // needs to be supplied at begin time; the layer passes all offsets.
    for (const id of ids) {
      if (id === element.id) offsets[id] = { x: point.x - element.x, y: point.y - element.y };
    }
    dispatch({ type: "beginMove", ids, offsets, point });
  }, []);

  const beginMoveWithOffsets = useCallback((ids: string[], offsets: Record<string, { x: number; y: number }>, point: { x: number; y: number }) => {
    dispatch({ type: "beginMove", ids, offsets, point });
  }, []);

  const beginResize = useCallback((element: AnyElement, handle: ResizeHandle, client: { x: number; y: number }) => {
    dispatch({
      type: "beginResize",
      id: element.id,
      handle,
      start: { x: element.x, y: element.y, width: element.width, height: element.height },
      startRotation: element.rotation,
      startFontSize: element.type === "text" ? (element as TextElement).fontSize : undefined,
      startClient: client,
    });
  }, []);

  const beginRotate = useCallback((element: AnyElement, client: { x: number; y: number }) => {
    const active = callbacksRef.current;
    const rect = active.getLayerRect();
    if (!rect) return;
    const screen = elementScreenRect(element.x, element.y, element.width, element.height, active.pageRotation, active.pageWidth, active.pageHeight, active.scale);
    const center = { x: rect.left + screen.left + screen.width / 2, y: rect.top + screen.top + screen.height / 2 };
    dispatch({
      type: "beginRotate",
      id: element.id,
      center,
      startAngle: Math.atan2(client.y - center.y, client.x - center.x),
      startRotation: element.rotation,
      latest: { x: client.x, y: client.y, shift: false },
    });
  }, []);

  useEffect(() => {
    if (!interaction) return;
    const onPointerMove = (event: PointerEvent) => {
      const active = callbacksRef.current;
      if (interaction.kind === "move") {
        const point = active.toPagePoint(event.clientX, event.clientY);
        if (point) dispatch({ type: "movePointer", point });
      } else if (interaction.kind === "resize") {
        dispatch({ type: "moveClient", client: { x: event.clientX, y: event.clientY } });
      } else {
        dispatch({ type: "rotatePointer", latest: { x: event.clientX, y: event.clientY, shift: event.shiftKey } });
      }
    };
    const finish = () => {
      const active = callbacksRef.current;
      if (interaction.kind === "move") {
        const finalPoint = interaction.point;
        active.onCommitElements(new Set(interaction.ids), (element) => {
          const offset = interaction.offsets[element.id];
          return offset ? { x: finalPoint.x - offset.x, y: finalPoint.y - offset.y } : {};
        });
      } else if (interaction.kind === "resize") {
        const patch = resizePatch(interaction, active.scale, active.pageRotation);
        if (patch) active.onCommitElements(new Set([interaction.id]), () => patch);
      } else {
        active.onCommitElements(new Set([interaction.id]), () => ({ rotation: rotationValue(interaction) }));
      }
      dispatch({ type: "end" });
    };
    const cancel = () => dispatch({ type: "end" });

    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", finish, { once: true });
    window.addEventListener("pointercancel", cancel, { once: true });
    window.addEventListener("blur", cancel, { once: true });
    document.addEventListener("visibilitychange", cancel, { once: true });
    return () => {
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", finish);
      window.removeEventListener("pointercancel", cancel);
      window.removeEventListener("blur", cancel);
      document.removeEventListener("visibilitychange", cancel);
    };
  }, [interaction]);

  const preview = useMemo(() => {
    if (!interaction) return new Map<string, Partial<AnyElement>>();
    if (interaction.kind === "move") {
      return new Map(interaction.ids.map((id) => {
        const offset = interaction.offsets[id];
        return [id, offset ? { x: interaction.point.x - offset.x, y: interaction.point.y - offset.y } : {}];
      }));
    }
    if (interaction.kind === "resize") {
      const patch = resizePatch(interaction, callbacksRef.current.scale, callbacksRef.current.pageRotation);
      return patch ? new Map([[interaction.id, patch]]) : new Map();
    }
    return new Map([[interaction.id, { rotation: rotationValue(interaction) }]]);
  }, [interaction]);

  return { interaction, beginMove, beginMoveWithOffsets, beginResize, beginRotate, preview };
}

function resizePatch(interaction: ResizeInteraction, scale: number, pageRotation: number) {
  const dxScreen = (interaction.latestClient.x - interaction.startClient.x) / scale;
  const dyScreen = (interaction.latestClient.y - interaction.startClient.y) / scale;
  const { dx, dy } = rotateVector(dxScreen, dyScreen, -(pageRotation + interaction.startRotation));
  const box = applyResizeHandle(interaction.handle, interaction.start, dx, dy);
  const patch: Partial<AnyElement> = { x: box.x, y: box.y, width: box.width, height: box.height };
  if (interaction.startFontSize && interaction.handle.length === 2) {
    const factor = Math.max(0.35, Math.min(4, Math.max(box.width / interaction.start.width, box.height / interaction.start.height)));
    (patch as Partial<TextElement>).fontSize = Math.max(6, Math.min(96, +(interaction.startFontSize * factor).toFixed(1)));
  }
  return patch;
}

function rotationValue(interaction: RotateInteraction) {
  const angle = Math.atan2(interaction.latest.y - interaction.center.y, interaction.latest.x - interaction.center.x);
  let rotation = Math.round(interaction.startRotation + ((angle - interaction.startAngle) * 180) / Math.PI);
  if (interaction.latest.shift) rotation = Math.round(rotation / 15) * 15;
  return ((rotation % 360) + 360) % 360;
}

export { applyResizeHandle, rotationValue, resizePatch };
