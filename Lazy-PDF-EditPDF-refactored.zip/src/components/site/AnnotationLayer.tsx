import { useCallback, useEffect, useMemo, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { makeId, ROTATABLE_TYPES, type AnyElement, type DrawElement, type FieldCheckboxElement, type FieldDropdownElement, type FieldRadioElement, type FieldTextElement, type HighlightElement, type ImageElement, type ShapeElement, type StickyElement, type TextElement } from "@/lib/pdf-annotations";
import { elementScreenRect, rotatePointToScreen, screenPointToPdf } from "@/lib/pdf-editor-coordinates";
import { useElementTransform } from "./hooks/useElementTransform";
import type { ResizeHandle, Tool } from "./editor-types";

function starSvgPoints(cx: number, cy: number, outerR: number, innerR: number) {
  return Array.from({ length: 10 }, (_, i) => {
    const angle = (i * Math.PI) / 5 - Math.PI / 2;
    const radius = i % 2 === 0 ? outerR : innerR;
    return `${cx + radius * Math.cos(angle)},${cy + radius * Math.sin(angle)}`;
  }).join(" ");
}

function eraseFromDrawElements(eraserPt: { x: number; y: number }, radius: number, drawEls: DrawElement[]) {
  const toRemove: string[] = [];
  const toAdd: DrawElement[] = [];
  for (const el of drawEls) {
    const margin = radius + 1;
    if (eraserPt.x < el.x - margin || eraserPt.x > el.x + el.width + margin || eraserPt.y < el.y - margin || eraserPt.y > el.y + el.height + margin) continue;
    const hit = el.points.some((p) => Math.hypot(p.x + el.x - eraserPt.x, p.y + el.y - eraserPt.y) <= radius);
    if (!hit) continue;
    toRemove.push(el.id);
    let segment: { x: number; y: number }[] = [];
    const segments: { x: number; y: number }[][] = [];
    for (const p of el.points) {
      if (Math.hypot(p.x + el.x - eraserPt.x, p.y + el.y - eraserPt.y) <= radius) {
        if (segment.length >= 2) segments.push(segment);
        segment = [];
      } else segment.push(p);
    }
    if (segment.length >= 2) segments.push(segment);
    for (const points of segments) {
      const absX = points.map((p) => p.x + el.x);
      const absY = points.map((p) => p.y + el.y);
      const minX = Math.min(...absX), minY = Math.min(...absY);
      const maxX = Math.max(...absX), maxY = Math.max(...absY);
      toAdd.push({ ...el, id: makeId("draw"), x: minX, y: minY, width: Math.max(1, maxX - minX), height: Math.max(1, maxY - minY), points: points.map((p) => ({ x: p.x + el.x - minX, y: p.y + el.y - minY })) });
    }
  }
  return { toRemove, toAdd };
}

export function AnnotationLayer(props: {
  pageId: string; scale: number; elements: AnyElement[]; activeTool: Tool;
  selectedIds: Set<string>; onSetSelectedIds: (ids: Set<string>) => void;
  onAddElement: (el: AnyElement) => void; onAddElementKeepTool: (el: AnyElement) => void;
  onAddTextAt: (pageId: string, x: number, y: number) => void;
  onBeginTextEdit: (id: string) => void; onFinishTextEdit: (id: string, text: string, cancel?: boolean) => void; editingTextId: string | null;
  onUpdateElement: (id: string, patch: Partial<AnyElement>) => void;
  onUpdateElements: (ids: Set<string>, patchFn: (e: AnyElement) => Partial<AnyElement>) => void;
  onDuplicateElements: (ids: Set<string>) => void;
  onReplaceElements: (toRemove: string[], toAdd: AnyElement[]) => void;
  onSelectionRectChange?: (rect: DOMRect | null) => void;
  interactive: boolean;
  drawStroke: { color: string; width: number }; eraserSize: number;
  highlightSettings: { color: string; opacity: number }; shapeDefaults: { stroke: string; strokeWidth: number; fill: string | null; dash: "solid" | "dashed" | "dotted" };
  /** Current page rotation (0/90/180/270) and the page's UNROTATED size in PDF points. */
  pageRotation: 0 | 90 | 180 | 270; unrotatedPageWidth: number; unrotatedPageHeight: number;
}) {
  const layerRef = useRef<HTMLDivElement | null>(null);
  const { pageRotation, unrotatedPageWidth: pageW, unrotatedPageHeight: pageH } = props;
  const elementsRef = useRef(props.elements);
  
  useEffect(() => { elementsRef.current = props.elements; }, [props.elements]);

  const [draft, setDraft] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [drawPoints, setDrawPoints] = useState<{ x: number; y: number }[] | null>(null);
  const [marquee, setMarquee] = useState<{ x: number; y: number; w: number; h: number } | null>(null);
  const [eraserPos, setEraserPos] = useState<{ x: number; y: number } | null>(null);

  const toPt = useCallback((clientX: number, clientY: number) => {
    const rect = layerRef.current?.getBoundingClientRect();
    if (!rect) return null;
    return screenPointToPdf(clientX, clientY, rect, props.scale, pageRotation, pageW, pageH);
  }, [props.scale, pageRotation, pageW, pageH]);

  const rectToScreenStyle = useCallback((x: number, y: number, w: number, h: number) =>
    elementScreenRect(x, y, w, h, pageRotation, pageW, pageH, props.scale),
  [props.scale, pageRotation, pageW, pageH]);

  const { interaction, beginMoveWithOffsets, beginResize, beginRotate, preview } = useElementTransform({
    scale: props.scale,
    pageRotation,
    pageWidth: pageW,
    pageHeight: pageH,
    getLayerRect: () => layerRef.current?.getBoundingClientRect() ?? null,
    toPagePoint: toPt,
    onCommitElements: props.onUpdateElements,
  });

  useEffect(() => {
    const selected = props.selectedIds.size === 1 ? props.elements.find((element) => props.selectedIds.has(element.id)) : undefined;
    const node = selected ? layerRef.current?.querySelector<HTMLElement>(`[data-element-id="${selected.id}"]`) : null;
    if (!node) return;
    const update = () => props.onSelectionRectChange?.(node.getBoundingClientRect());
    update();
    const ro = new ResizeObserver(update);
    ro.observe(node);
    window.addEventListener("scroll", update, true);
    window.addEventListener("resize", update);
    return () => { ro.disconnect(); window.removeEventListener("scroll", update, true); window.removeEventListener("resize", update); };
  }, [props.selectedIds, props.elements, props.onSelectionRectChange, interaction]);

  useEffect(() => {
    if (!props.selectedIds.size) props.onSelectionRectChange?.(null);
  }, [props.selectedIds.size, props.onSelectionRectChange]);

  const nonCreationTools: Tool[] = ["select", "hand", "image", "signature", "eraser"];
  const isCreationTool = props.interactive && !nonCreationTools.includes(props.activeTool);
  const isShapeTool = props.activeTool.startsWith("shape-");
  const isFieldTool = props.activeTool.startsWith("field-");
  const creationDragRef = useRef<{ startPt: { x: number; y: number } } | null>(null);

  function onLayerPointerDown(e: ReactPointerEvent) {
    if (!props.interactive) return;

    // ERASER TOOL
    if (props.activeTool === "eraser") {
      e.preventDefault();
      const pt = toPt(e.clientX, e.clientY);
      if (!pt) return;
      setEraserPos(pt);
      const drawEls = props.elements.filter((el) => el.type === "draw") as DrawElement[];
      const { toRemove, toAdd } = eraseFromDrawElements(pt, props.eraserSize, drawEls);
      if (toRemove.length > 0) props.onReplaceElements(toRemove, toAdd);
      const onMove = (ev: PointerEvent) => {
        const p = toPt(ev.clientX, ev.clientY); if (!p) return; setEraserPos(p);
        const curr = elementsRef.current.filter((el) => el.type === "draw") as DrawElement[];
        const res = eraseFromDrawElements(p, props.eraserSize, curr);
        if (res.toRemove.length > 0) props.onReplaceElements(res.toRemove, res.toAdd);
      };
      const onUp = () => { setEraserPos(null); window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp); };
      window.addEventListener("pointermove", onMove); window.addEventListener("pointerup", onUp);
      return;
    }

    // SELECT / MARQUEE
    if (!isCreationTool) {
      if (e.target === layerRef.current) {
        if (e.shiftKey || e.metaKey || e.ctrlKey) return;
        props.onSetSelectedIds(new Set());
        const start = toPt(e.clientX, e.clientY);
        if (!start) return;
        setMarquee({ x: start.x, y: start.y, w: 0, h: 0 });
        const onMove = (ev: PointerEvent) => { const p = toPt(ev.clientX, ev.clientY); setMarquee({ x: Math.min(start.x, p.x), y: Math.min(start.y, p.y), w: Math.abs(p.x - start.x), h: Math.abs(p.y - start.y) }); };
        const onUp = (ev: PointerEvent) => {
          window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp);
          const p = toPt(ev.clientX, ev.clientY);
          if (!p) return;
          const r = { x1: Math.min(start.x, p.x), y1: Math.min(start.y, p.y), x2: Math.max(start.x, p.x), y2: Math.max(start.y, p.y) };
          if (Math.abs(r.x2 - r.x1) > 3 || Math.abs(r.y2 - r.y1) > 3) props.onSetSelectedIds(new Set(props.elements.filter((el) => { const b = { x1: el.x, y1: el.y, x2: el.x + el.width, y2: el.y + el.height }; return r.x1 < b.x2 && r.x2 > b.x1 && r.y1 < b.y2 && r.y2 > b.y1; }).map((el) => el.id)));
          setMarquee(null);
        };
        window.addEventListener("pointermove", onMove); window.addEventListener("pointerup", onUp);
      }
      return;
    }

    const pt = toPt(e.clientX, e.clientY);
    if (!pt) return;

    // Single-click tools. Text is one-shot: exactly one box per click, edit starts immediately.
    if (props.activeTool === "text") { if (e.target === layerRef.current) props.onAddTextAt(props.pageId, pt.x, pt.y); return; }
    if (props.activeTool === "sticky") { props.onAddElement({ id: makeId("sticky"), pageId: props.pageId, type: "sticky", x: pt.x, y: pt.y, width: 140, height: 100, opacity: 1, rotation: 0, color: "#FEF08A", note: "" } as StickyElement); return; }
    if (isFieldTool) {
      const base = { id: makeId(props.activeTool), pageId: props.pageId, opacity: 1, rotation: 0, x: pt.x, y: pt.y } as const;
      let el: AnyElement | null = null;
      if (props.activeTool === "field-text") el = { ...base, type: "field-text", width: 180, height: 26, name: "text_field", value: "", placeholder: "Enter text", required: false } as FieldTextElement;
      else if (props.activeTool === "field-checkbox") el = { ...base, type: "field-checkbox", width: 18, height: 18, name: "checkbox", checked: false, required: false } as FieldCheckboxElement;
      else if (props.activeTool === "field-radio") el = { ...base, type: "field-radio", width: 18, height: 18, groupName: "radio_group", value: "option_1", checked: false, required: false } as FieldRadioElement;
      else if (props.activeTool === "field-dropdown") el = { ...base, type: "field-dropdown", width: 160, height: 26, name: "dropdown", options: ["Option 1", "Option 2"], value: "Option 1", required: false } as FieldDropdownElement;
      if (el) props.onAddElement(el); return;
    }

    // Drag-based tools
    creationDragRef.current = { startPt: pt };
    if (props.activeTool === "draw") setDrawPoints([pt]);
    else setDraft({ x: pt.x, y: pt.y, w: 0, h: 0 });

    const onMove = (ev: PointerEvent) => {
      const p = toPt(ev.clientX, ev.clientY);
      if (props.activeTool === "draw") setDrawPoints((pts) => pts ? [...pts, p] : [p]);
      else if (p) { const s = creationDragRef.current?.startPt; if (!s) return; setDraft({ x: Math.min(s.x, p.x), y: Math.min(s.y, p.y), w: Math.abs(p.x - s.x), h: Math.abs(p.y - s.y) }); }
    };
    const onUp = (ev: PointerEvent) => {
      window.removeEventListener("pointermove", onMove); window.removeEventListener("pointerup", onUp);
      const p = toPt(ev.clientX, ev.clientY);
      const start = creationDragRef.current?.startPt ?? p;
      creationDragRef.current = null;

      if (props.activeTool === "draw") {
        setDrawPoints((pts) => {
          if (pts && pts.length > 1) {
            const xs = pts.map((pp) => pp.x), ys = pts.map((pp) => pp.y);
            const minX = Math.min(...xs), minY = Math.min(...ys), maxX = Math.max(...xs), maxY = Math.max(...ys);
            props.onAddElementKeepTool({ id: makeId("draw"), pageId: props.pageId, type: "draw", x: minX, y: minY, width: Math.max(1, maxX - minX), height: Math.max(1, maxY - minY), opacity: 1, rotation: 0, stroke: props.drawStroke.color, strokeWidth: props.drawStroke.width, points: pts.map((pp) => ({ x: pp.x - minX, y: pp.y - minY })) } as DrawElement);
          }
          return null;
        });
        return;
      }

      if (!p) { setDraft(null); return; }
      const x = Math.min(start.x, p.x), y = Math.min(start.y, p.y);
      const w = Math.max(8, Math.abs(p.x - start.x)), h = Math.max(8, Math.abs(p.y - start.y));
      setDraft(null);

      if (isShapeTool) {
        const flipDiag = (start.x < p.x) !== (start.y < p.y);
        props.onAddElement({
          id: makeId("shape"), pageId: props.pageId, type: props.activeTool.replace("shape-", ""),
          x, y, width: w, height: h, opacity: 1, rotation: 0,
          stroke: props.shapeDefaults.stroke, strokeWidth: props.shapeDefaults.strokeWidth,
          fill: props.shapeDefaults.fill, dash: props.shapeDefaults.dash, flipDiag,
        } as unknown as ShapeElement);
      } else if (["highlight","underline","strikeout","squiggly"].includes(props.activeTool)) {
        props.onAddElement({
          id: makeId("markup"),
          pageId: props.pageId,
          type: props.activeTool,
          x, y, width: w, height: h,
          opacity: props.activeTool === "highlight" ? props.highlightSettings.opacity : 1,
          rotation: 0,
          color: props.activeTool === "highlight" ? props.highlightSettings.color : "#FDE047",
        } as HighlightElement);
      } else if (props.activeTool === "whiteout") {
        props.onAddElementKeepTool({ id: makeId("wo"), pageId: props.pageId, type: "whiteout", x, y, width: w, height: h, opacity: 1, rotation: 0, color: "#ffffff" });
      }
    };
    window.addEventListener("pointermove", onMove); window.addEventListener("pointerup", onUp);
  }

  function startMove(e: ReactPointerEvent, el: AnyElement) {
    if (!props.interactive || props.activeTool !== "select" || props.editingTextId) return;
    e.stopPropagation();
    let ids = props.selectedIds;
    if (e.shiftKey || e.metaKey || e.ctrlKey) {
      const next = new Set(ids);
      if (next.has(el.id)) next.delete(el.id); else next.add(el.id);
      props.onSetSelectedIds(next);
      ids = next;
    } else if (!ids.has(el.id)) {
      ids = new Set([el.id]);
      props.onSetSelectedIds(ids);
    }
    if (!ids.has(el.id)) return;
    if (e.altKey) { props.onDuplicateElements(ids); return; }
    const point = toPt(e.clientX, e.clientY);
    if (!point) return;
    const offsets: Record<string, { x: number; y: number }> = {};
    for (const id of ids) {
      const item = props.elements.find((candidate) => candidate.id === id);
      if (item) offsets[id] = { x: point.x - item.x, y: point.y - item.y };
    }
    beginMoveWithOffsets(Array.from(ids), offsets, point);
  }

  const isInteractiveDrawing = props.activeTool === "draw" || props.activeTool === "eraser" || isCreationTool;

  return (
    <div ref={layerRef} className="absolute inset-0"
      style={{ cursor: props.activeTool === "eraser" ? "none" : isCreationTool ? "crosshair" : "default", pointerEvents: props.interactive ? "auto" : "none", touchAction: isInteractiveDrawing ? "none" : undefined }}
      onPointerDown={onLayerPointerDown}>

      {props.elements.map((rawEl) => {
        const el = preview.has(rawEl.id) ? ({ ...rawEl, ...preview.get(rawEl.id) } as AnyElement) : rawEl;
        const selected = props.selectedIds.has(el.id);
        const isOnlySelected = selected && props.selectedIds.size === 1;
        const isEditingThis = props.editingTextId === el.id;
        const canRotate = isOnlySelected && props.activeTool === "select" && ROTATABLE_TYPES.has(el.type);
        const canResize = isOnlySelected && props.activeTool === "select" && el.type !== "draw" && !el.type.startsWith("field-");
        const s = el as ShapeElement & { flipDiag?: boolean; dash?: "solid" | "dashed" | "dotted" };
        const sw = el.width * props.scale, sh = el.height * props.scale;
        const screenRect = rectToScreenStyle(el.x, el.y, el.width, el.height);
        const totalRotationDeg = (el.rotation || 0) + pageRotation;

        const style: CSSProperties = {
          position: "absolute", left: screenRect.left, top: screenRect.top, width: sw, height: sh,
          opacity: el.opacity, transform: totalRotationDeg ? `rotate(${totalRotationDeg}deg)` : undefined,
          transformOrigin: "center center"
        };

        let body: React.ReactNode = null;
        if (el.type === "text") {
          const t = el as TextElement;
          const fontFamily = t.font === "TimesRoman" ? "Times New Roman, serif" : t.font === "Courier" ? "monospace" : `"${t.font}", Helvetica, Arial, sans-serif`;
          const textStyle: CSSProperties = {
            width: "100%", height: "100%", boxSizing: "border-box", display: "block", margin: 0, border: "none",
            fontFamily, fontSize: t.fontSize * props.scale, fontWeight: t.bold ? 700 : 400, fontStyle: t.italic ? "italic" : "normal",
            textDecoration: t.underline ? "underline" : "none", color: t.color, textAlign: t.align, whiteSpace: "pre-wrap",
            outline: "none", lineHeight: t.lineSpacing, letterSpacing: `${t.letterSpacing * props.scale}px`,
            padding: `${2 * props.scale}px ${3 * props.scale}px`, background: "transparent", resize: "none", overflow: "hidden",
          };
          body = isEditingThis ? (
            <TextEditBox key={el.id} initialText={t.text} style={textStyle}
              onCommit={(text) => props.onFinishTextEdit(el.id, text)}
              onCancel={() => props.onFinishTextEdit(el.id, t.text, true)}
            />
          ) : (
            <div data-el-content onDoubleClick={(e2) => { e2.stopPropagation(); props.onBeginTextEdit(el.id); }} style={{ ...textStyle, cursor: props.activeTool === "select" ? "move" : "text", userSelect: "none" }}>
              {t.text || <span style={{ opacity: 0.4 }}>Text</span>}
            </div>
          );
        } else if (el.type === "rect") {
          body = <div style={{ width: "100%", height: "100%", border: `${s.strokeWidth * props.scale}px ${s.dash === "dashed" ? "dashed" : s.dash === "dotted" ? "dotted" : "solid"} ${s.stroke}`, background: s.fill ?? "transparent" }} />;
        } else if ((el.type as string) === "rounded-rect") {
          body = <div style={{ width: "100%", height: "100%", borderRadius: 12 * props.scale, border: `${s.strokeWidth * props.scale}px ${s.dash === "dashed" ? "dashed" : s.dash === "dotted" ? "dotted" : "solid"} ${s.stroke}`, background: s.fill ?? "transparent" }} />;
        } else if (el.type === "ellipse") {
          body = <div style={{ width: "100%", height: "100%", borderRadius: "50%", border: `${s.strokeWidth * props.scale}px ${s.dash === "dashed" ? "dashed" : s.dash === "dotted" ? "dotted" : "solid"} ${s.stroke}`, background: s.fill ?? "transparent" }} />;
        } else if (el.type === "line") {
          const flip = (s as any).flipDiag;
          body = (<svg width="100%" height="100%" style={{ overflow: "visible" }}><line x1={0} y1={flip ? sh : 0} x2={sw} y2={flip ? 0 : sh} stroke={s.stroke} strokeWidth={s.strokeWidth * props.scale} strokeDasharray={s.dash === "dashed" ? "8 6" : s.dash === "dotted" ? "2 4" : "none"} strokeLinecap="round" /></svg>);
        } else if ((el.type as string) === "arrow") {
          const aw = Math.max(10, Math.min(sw * 0.25, sh * 0.8));
          const ah = aw * 0.65;
          body = (<svg width="100%" height="100%" viewBox={`0 0 ${sw} ${sh}`} style={{ overflow: "visible" }}>
            <line x1={0} y1={sh / 2} x2={sw - aw * 0.8} y2={sh / 2} stroke={s.stroke} strokeWidth={s.strokeWidth * props.scale} strokeDasharray={s.dash === "dashed" ? "8 6" : s.dash === "dotted" ? "2 4" : "none"} strokeLinecap="round" />
            <polygon points={`${sw - aw},${sh / 2 - ah / 2} ${sw},${sh / 2} ${sw - aw},${sh / 2 + ah / 2}`} fill={s.stroke} />
          </svg>);
        } else if ((el.type as string) === "triangle") {
          body = (<svg width="100%" height="100%" viewBox={`0 0 ${sw} ${sh}`} style={{ overflow: "visible" }}>
            <polygon points={`${sw / 2},0 ${sw},${sh} 0,${sh}`} fill={s.fill ?? "none"} stroke={s.stroke} strokeWidth={s.strokeWidth * props.scale} strokeDasharray={s.dash === "dashed" ? "8 6" : s.dash === "dotted" ? "2 4" : "none"} strokeLinejoin="round" />
          </svg>);
        } else if ((el.type as string) === "star") {
          const cx = sw / 2, cy = sh / 2, outerR = Math.min(cx, cy) * 0.98, innerR = outerR * 0.42;
          body = (<svg width="100%" height="100%" viewBox={`0 0 ${sw} ${sh}`} style={{ overflow: "visible" }}>
            <polygon points={starSvgPoints(cx, cy, outerR, innerR)} fill={s.fill ?? "none"} stroke={s.stroke} strokeWidth={s.strokeWidth * props.scale} strokeDasharray={s.dash === "dashed" ? "8 6" : s.dash === "dotted" ? "2 4" : "none"} strokeLinejoin="round" />
          </svg>);
        } else if ((el.type as string) === "speech") {
          const r = Math.min(10, sw * 0.05, sh * 0.08);
          const tailH = sh * 0.22, bubH = sh - tailH;
          body = (<svg width="100%" height="100%" viewBox={`0 0 ${sw} ${sh}`} style={{ overflow: "visible" }}>
            <path d={`M ${r},0 L ${sw - r},0 Q ${sw},0 ${sw},${r} L ${sw},${bubH - r} Q ${sw},${bubH} ${sw - r},${bubH} L ${sw * 0.38},${bubH} L ${sw * 0.22},${sh} L ${sw * 0.3},${bubH} L ${r},${bubH} Q 0,${bubH} 0,${bubH - r} L 0,${r} Q 0,0 ${r},0 Z`} fill={s.fill ?? "white"} stroke={s.stroke} strokeWidth={s.strokeWidth * props.scale} strokeDasharray={s.dash === "dashed" ? "8 6" : s.dash === "dotted" ? "2 4" : "none"} strokeLinejoin="round" />
          </svg>);
        } else if (el.type === "draw") {
          const d = el as DrawElement;
          const pts = d.points.map((p) => `${p.x * props.scale},${p.y * props.scale}`).join(" ");
          body = (<svg className="absolute inset-0 w-full h-full" style={{ overflow: "visible" }}>
            <polyline points={pts} fill="none" stroke={d.stroke} strokeWidth={d.strokeWidth * props.scale} strokeLinecap="round" strokeLinejoin="round" />
          </svg>);
        } else if (el.type === "highlight") {
          body = <div style={{ width: "100%", height: "100%", background: (el as HighlightElement).color }} />;
        } else if (el.type === "underline") {
          body = <div style={{ width: "100%", height: Math.max(1, 2 * props.scale), marginTop: el.height * props.scale - 2 * props.scale, background: (el as HighlightElement).color }} />;
        } else if (el.type === "strikeout") {
          body = <div style={{ width: "100%", height: Math.max(1, 2 * props.scale), marginTop: (el.height * props.scale) / 2, background: (el as HighlightElement).color }} />;
        } else if (el.type === "squiggly") {
          body = (<svg width="100%" height="100%" style={{ overflow: "visible" }}>
            <polyline points={Array.from({ length: 10 }, (_, i) => `${i * (el.width / 9) * props.scale},${el.height * props.scale - (i % 2 === 0 ? 0 : 4 * props.scale)}`).join(" ")} fill="none" stroke={(el as HighlightElement).color} strokeWidth={1.6 * props.scale} />
          </svg>);
        } else if (el.type === "whiteout") {
          body = <div style={{ width: "100%", height: "100%", background: (el as { color: string }).color || "#ffffff" }} />;
        } else if (el.type === "image") {
          body = <img src={(el as ImageElement).src} draggable={false} style={{ width: "100%", height: "100%", objectFit: "fill" }} />;
        } else if (el.type === "sticky") {
          const st = el as StickyElement;
          body = (<div style={{ width: "100%", height: "100%", background: st.color, border: "1px solid rgba(0,0,0,0.15)", borderRadius: 4, boxShadow: "0 2px 6px rgba(0,0,0,0.15)", padding: 4 * props.scale, overflow: "hidden" }}>
            <textarea value={st.note} onChange={(e2) => props.onUpdateElement(el.id, { note: e2.target.value })} onPointerDown={(e2) => e2.stopPropagation()} placeholder="Note…" style={{ width: "100%", height: "100%", background: "transparent", border: "none", outline: "none", resize: "none", fontSize: 11 * Math.max(1, props.scale), color: "#3F3300" }} />
          </div>);
        } else if (el.type === "field-text") {
          const f = el as FieldTextElement;
          body = <input value={f.value} placeholder={f.placeholder} onChange={(e2) => props.onUpdateElement(el.id, { value: e2.target.value })} onPointerDown={(e2) => e2.stopPropagation()} style={{ width: "100%", height: "100%", border: `${1.5 * props.scale}px solid #DC2626`, borderRadius: 4, background: "rgba(220,38,38,0.05)", fontSize: 12 * Math.max(1, props.scale), padding: `0 ${6 * props.scale}px`, outline: "none" }} />;
        } else if (el.type === "field-checkbox") {
          const f = el as FieldCheckboxElement;
          body = (<div onPointerDown={(e2) => { e2.stopPropagation(); props.onUpdateElement(el.id, { checked: !f.checked }); }} style={{ width: "100%", height: "100%", border: `${1.5 * props.scale}px solid #DC2626`, borderRadius: 3, background: f.checked ? "#DC2626" : "rgba(220,38,38,0.05)", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
            {f.checked && <Check style={{ width: "80%", height: "80%" }} className="text-white" />}
          </div>);
        } else if (el.type === "field-radio") {
          const f = el as FieldRadioElement;
          body = (<div onPointerDown={(e2) => { e2.stopPropagation(); props.onUpdateElement(el.id, { checked: !f.checked }); }} style={{ width: "100%", height: "100%", borderRadius: "50%", border: `${1.5 * props.scale}px solid #DC2626`, background: "rgba(220,38,38,0.05)", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
            {f.checked && <div style={{ width: "55%", height: "55%", borderRadius: "50%", background: "#DC2626" }} />}
          </div>);
        } else if (el.type === "field-dropdown") {
          const f = el as FieldDropdownElement;
          body = (<select value={f.value} onChange={(e2) => props.onUpdateElement(el.id, { value: e2.target.value })} onPointerDown={(e2) => e2.stopPropagation()} style={{ width: "100%", height: "100%", border: `${1.5 * props.scale}px solid #DC2626`, borderRadius: 4, background: "rgba(220,38,38,0.05)", fontSize: 12 * Math.max(1, props.scale) }}>
            {f.options.map((o) => <option key={o} value={o}>{o}</option>)}
          </select>);
        }

        return (
          <div key={el.id} data-element-id={el.id} style={{ ...style, pointerEvents: props.activeTool === "select" ? "auto" : el.type === "text" && props.activeTool === "text" ? "auto" : "none" }}
            onPointerDown={props.activeTool === "select" ? (e) => startMove(e, rawEl) : el.type === "text" && props.activeTool === "text" ? (e) => { e.stopPropagation(); props.onBeginTextEdit(el.id); } : undefined}
            className={cn(
              selected && props.activeTool === "select" && !isEditingThis && "outline outline-2 outline-[#DC2626] outline-offset-1",
              isEditingThis && "outline outline-2 outline-[#DC2626] outline-offset-1 ring-2 ring-[#DC2626]/20",
            )}>
            {body}
            {canResize && (isOnlySelected || isEditingThis) && RESIZE_HANDLES.map((h) => (
              <div key={h} onPointerDown={(e) => startResize(e, el, h)}
                style={{ position: "absolute", ...RESIZE_HANDLE_STYLE[h], width: 10, height: 10, borderRadius: 3, background: "#fff", border: "2px solid #DC2626", boxShadow: "0 1px 4px rgba(15,23,42,0.3)", zIndex: 20, touchAction: "none" }} />
            ))}
            {canRotate && (<div onPointerDown={(e) => startRotate(e, el)} style={{ position: "absolute", left: "50%", top: -22, width: 10, height: 10, marginLeft: -5, borderRadius: "50%", background: "#DC2626", cursor: "grab", touchAction: "none" }} />)}
          </div>
        );
      })}

      {draft && (() => { const r = rectToScreenStyle(draft.x, draft.y, draft.w, draft.h); return (<div style={{ position: "absolute", left: r.left, top: r.top, width: r.width, height: r.height, transform: pageRotation ? `rotate(${pageRotation}deg)` : undefined, transformOrigin: "center center", border: "1.5px dashed #DC2626", background: props.activeTool === "highlight" ? "rgba(253,224,71,0.35)" : "rgba(220,38,38,0.06)", pointerEvents: "none" }} />); })()}
      {drawPoints && drawPoints.length > 1 && (
        <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: "none", overflow: "visible" }}>
          <polyline points={drawPoints.map((p) => { const s = rotatePointToScreen(p.x, p.y, pageRotation, pageW, pageH); return `${s.x * props.scale},${s.y * props.scale}`; }).join(" ")} fill="none" stroke={props.drawStroke.color} strokeWidth={props.drawStroke.width * props.scale} strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      )}
      {marquee && (() => { const r = rectToScreenStyle(marquee.x, marquee.y, marquee.w, marquee.h); return (<div style={{ position: "absolute", left: r.left, top: r.top, width: r.width, height: r.height, transform: pageRotation ? `rotate(${pageRotation}deg)` : undefined, transformOrigin: "center center", border: "1px dashed #DC2626", background: "rgba(220,38,38,0.08)", pointerEvents: "none" }} />); })()}
      {eraserPos && (() => { const r = rectToScreenStyle(eraserPos.x - props.eraserSize, eraserPos.y - props.eraserSize, props.eraserSize * 2, props.eraserSize * 2); return (<div style={{ position: "absolute", left: r.left, top: r.top, width: r.width, height: r.height, borderRadius: "50%", border: "2px solid #DC2626", background: "rgba(220,38,38,0.08)", pointerEvents: "none" }} />); })()}
    </div>
  );
}

/** Controlled text-edit textarea. Fully React-state-backed (not
 * contentEditable) so the caret and value stay stable under React
 * re-renders. Focuses and places the caret at the end on mount; commits on
 * blur; a single `committedRef` guard prevents double-commit when Escape or
 * Ctrl/Cmd+Enter triggers a commit/cancel that then also causes a blur. */
function TextEditBox({ initialText, style, onCommit, onCancel }: { initialText: string; style: CSSProperties; onCommit: (text: string) => void; onCancel: () => void }) {
  const [value, setValue] = useState(initialText);
  const ref = useRef<HTMLTextAreaElement | null>(null);
  const settledRef = useRef(false);
  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    node.focus({ preventScroll: true });
    const len = node.value.length;
    node.setSelectionRange(len, len);
  }, []);
  function commitOnce() { if (settledRef.current) return; settledRef.current = true; onCommit(value); }
  function cancelOnce() { if (settledRef.current) return; settledRef.current = true; onCancel(); }
  return (
    <textarea
      ref={ref}
      data-el-content
      value={value}
      onChange={(e) => setValue(e.target.value)}
      onPointerDown={(e) => e.stopPropagation()}
      onClick={(e) => e.stopPropagation()}
      onKeyDown={(e) => {
        e.stopPropagation();
        if (e.key === "Escape") { e.preventDefault(); cancelOnce(); }
        else if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); commitOnce(); }
      }}
      onBlur={() => commitOnce()}
      spellCheck={false}
      style={{ ...style, cursor: "text" }}
    />
  );
}

