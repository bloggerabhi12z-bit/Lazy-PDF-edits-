import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  AlignCenter,
  AlignEndHorizontal,
  AlignHorizontalDistributeCenter,
  AlignLeft,
  AlignRight,
  ArrowDown,
  ArrowLeft,
  ArrowRight,
  ArrowUp,
  Bold,
  Copy,
  Download,
  Eraser,
  Hand,
  Highlighter,
  Image as ImageIcon,
  Italic,
  Layers,
  Loader2,
  MessageSquare,
  Minus,
  MoreHorizontal,
  MousePointer2,
  PenLine,
  PenTool,
  Redo2,
  RotateCw,
  Search,
  Square,
  Star,
  Trash2,
  Triangle,
  Type,
  Underline,
  Undo2,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import {
  FONT_OPTIONS,
  type AnyElement,
  type ImageElement,
  type ShapeElement,
  type TextElement,
} from "@/lib/pdf-annotations";
import type { EditorPage, Tool } from "./editor-types";

const GOOGLE_FONTS = [
  "Roboto",
  "Open Sans",
  "Lato",
  "Montserrat",
  "Poppins",
  "Inter",
  "Merriweather",
  "Playfair Display",
  "Nunito",
  "Raleway",
  "Ubuntu",
  "DM Sans",
  "Space Grotesk",
  "IBM Plex Sans",
  "Roboto Mono",
  "Caveat",
  "Pacifico",
  "Dancing Script",
  "Great Vibes",
  "Shadows Into Light",
  "Indie Flower",
];

const ACCENT = "#DC2626";

type Props = {
  fileName: string;
  pageCount: number;
  saveStatus: "saved" | "unsaved" | "saving";
  actionLabel: string;
  busy: boolean;
  processing: boolean;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  onApply: () => void;
  onReplace: () => void;
  activeTool: Tool;
  activeShape: Tool;
  annotateDisabled: boolean;
  editingTextId: string | null;
  selectedIds: Set<string>;
  selectedElements: AnyElement[];
  current: number;
  pages: EditorPage[];
  showSearch: boolean;
  searchQuery: string;
  searchResults: { pageIndex: number; snippet: string }[];
  searchActiveIdx: number;
  searching: boolean;
  onSearchToggle: () => void;
  onSearch: (query: string) => void;
  onSearchJump: (index: number) => void;
  onSearchClose: () => void;
  onSetActiveTool: (tool: Tool) => void;
  onSetActiveShape: (tool: Tool) => void;
  onOpenImage: () => void;
  onOpenSignature: () => void;
  onDelete: () => void;
  onDuplicate: () => void;
  onUpdateElement: (id: string, patch: Partial<AnyElement>) => void;
  onUpdateElements: (
    ids: Set<string>,
    patchFn: (e: AnyElement) => Partial<AnyElement>,
  ) => void;
  onAlign: (
    mode: "left" | "center" | "right" | "top" | "middle" | "bottom",
  ) => void;
  onDistribute: (axis: "horizontal" | "vertical") => void;
  onReorder: (dir: "forward" | "backward" | "front" | "back") => void;
  onOpenImageForSelected: () => void;
  onLoadCustomFont: (id: string, family: string) => void;
  selectionRect: DOMRect | null;
  drawStroke: { color: string; width: number };
  setDrawStroke: (value: { color: string; width: number }) => void;
  eraserSize: number;
  setEraserSize: (value: number) => void;
  highlightSettings: { color: string; opacity: number };
  setHighlightSettings: (value: { color: string; opacity: number }) => void;
  shapeDefaults: {
    stroke: string;
    strokeWidth: number;
    fill: string | null;
    dash: "solid" | "dashed" | "dotted";
  };
  setShapeDefaults: (value: {
    stroke: string;
    strokeWidth: number;
    fill: string | null;
    dash: "solid" | "dashed" | "dotted";
  }) => void;
  thumbs: Record<number, string>;
  showPagePanel: boolean;
  onTogglePagePanel: () => void;
  onPageClick: (index: number) => void;
  onRotatePage: (index: number, delta: number) => void;
  onDeletePage: (index: number) => void;
  onDuplicatePage: (index: number) => void;
  onInsertBlankPage: (index: number) => void;
  onMovePage: (from: number, to: number) => void;
};

function ToolButton({
  icon,
  label,
  active,
  disabled,
  onClick,
}: {
  icon: ReactNode;
  label: string;
  active?: boolean;
  disabled?: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      className={cn(
        "inline-flex h-9 shrink-0 items-center gap-1.5 rounded-xl px-2.5 text-xs font-medium transition-all",
        "text-slate-500 hover:bg-slate-100 hover:text-slate-900",
        "dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white",
        active &&
          "bg-red-50 text-[#DC2626] shadow-sm dark:bg-red-500/15 dark:text-red-300",
        disabled && "pointer-events-none opacity-30",
      )}
    >
      <span className="grid h-4 w-4 place-items-center [&>svg]:h-4 [&>svg]:w-4">
        {icon}
      </span>
      <span className="hidden lg:inline">{label}</span>
    </button>
  );
}

function Divider() {
  return (
    <div className="mx-1 h-6 w-px shrink-0 bg-slate-200 dark:bg-slate-800" />
  );
}

export function Toolbar(props: Props) {
  const [moreOpen, setMoreOpen] = useState(false);
  const [shapeOpen, setShapeOpen] = useState(false);

  useEffect(() => {
    if (!moreOpen && !shapeOpen) return;

    const onPointerDown = (event: PointerEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest("[data-toolbar-popover]")) return;
      setMoreOpen(false);
      setShapeOpen(false);
    };

    document.addEventListener("pointerdown", onPointerDown);
    return () =>
      document.removeEventListener("pointerdown", onPointerDown);
  }, [moreOpen, shapeOpen]);

  const shapeTools: { tool: Tool; label: string; icon: ReactNode }[] = [
    { tool: "shape-rect", label: "Rectangle", icon: <Square /> },
    { tool: "shape-ellipse", label: "Ellipse", icon: <span className="text-lg leading-none">○</span> },
    { tool: "shape-line", label: "Line", icon: <Minus /> },
    { tool: "shape-arrow", label: "Arrow", icon: <ArrowRight /> },
    { tool: "shape-triangle", label: "Triangle", icon: <Triangle /> },
    { tool: "shape-star", label: "Star", icon: <Star /> },
    { tool: "shape-rounded-rect", label: "Rounded", icon: <span className="text-base leading-none">▢</span> },
    { tool: "shape-speech", label: "Bubble", icon: <MessageSquare /> },
  ];

  const single = props.selectedElements.length === 1 ? props.selectedElements[0] : null;
  const selectedText = single?.type === "text" ? (single as TextElement) : null;
  const selectedShape =
    single &&
    [
      "rect",
      "ellipse",
      "line",
      "arrow",
      "triangle",
      "star",
      "rounded-rect",
      "speech",
    ].includes(single.type)
      ? (single as ShapeElement)
      : null;
  const selectedImage = single?.type === "image" ? (single as ImageElement) : null;
  const multi = props.selectedElements.length > 1;

  const contextual = useMemo(() => {
    if (!props.selectionRect || props.selectedElements.length === 0) return null;

    const rect = props.selectionRect;
    const width = Math.min(900, Math.max(420, window.innerWidth - 32));
    const left = Math.min(
      Math.max(16, rect.left + rect.width / 2 - width / 2),
      Math.max(16, window.innerWidth - width - 16),
    );
    const top = rect.top > 140
      ? rect.top - 58
      : Math.min(window.innerHeight - 66, rect.bottom + 8);

    return { left, top, width };
  }, [props.selectionRect, props.selectedElements.length]);

  const toolClass = (tool: Tool) => props.activeTool === tool;

  return (
    <>
      <header className="relative z-50 flex h-14 shrink-0 items-center justify-between gap-3 border-b border-slate-200/80 bg-white/95 px-3 backdrop-blur-xl dark:border-slate-800/80 dark:bg-slate-950/95">
        <div className="flex min-w-0 items-center gap-2.5">
          <button
            type="button"
            onClick={props.onReplace}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-800 dark:hover:text-white"
            title="Back"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>

          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-red-600 text-[9px] font-black text-white">
            PDF
          </div>

          <div className="min-w-0">
            <div className="max-w-[280px] truncate text-sm font-semibold text-slate-900 dark:text-white">
              {props.fileName}
            </div>
            <div className="mt-0.5 flex items-center gap-2 text-[10px] text-slate-400">
              <span>
                {props.pageCount} {props.pageCount === 1 ? "page" : "pages"}
              </span>
              <span>·</span>
              <span className="inline-flex items-center gap-1.5">
                <span
                  className={cn(
                    "h-1.5 w-1.5 rounded-full",
                    props.saveStatus === "saved" && "bg-emerald-500",
                    props.saveStatus === "unsaved" && "bg-amber-500",
                    props.saveStatus === "saving" && "animate-pulse bg-slate-400",
                  )}
                />
                {props.saveStatus === "saving"
                  ? "Saving…"
                  : props.saveStatus === "saved"
                    ? "Saved"
                    : "Unsaved changes"}
              </span>
            </div>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1">
          <ToolButton
            icon={<Undo2 />}
            label="Undo"
            disabled={!props.canUndo}
            onClick={props.onUndo}
          />
          <ToolButton
            icon={<Redo2 />}
            label="Redo"
            disabled={!props.canRedo}
            onClick={props.onRedo}
          />
          <ToolButton
            icon={<Search />}
            label="Search"
            active={props.showSearch}
            onClick={props.onSearchToggle}
          />
          <Divider />
          <button
            type="button"
            onClick={props.onApply}
            disabled={props.processing || props.busy}
            className="inline-flex h-9 items-center gap-2 rounded-xl bg-red-600 px-3.5 text-xs font-semibold text-white shadow-[0_8px_24px_-12px_rgba(220,38,38,0.95)] transition-colors hover:bg-red-700 disabled:pointer-events-none disabled:opacity-60"
          >
            {props.processing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Download className="h-4 w-4" />
            )}
            <span className="hidden sm:inline">
              {props.processing ? "Saving…" : props.actionLabel || "Save changes"}
            </span>
          </button>
        </div>
      </header>

      {props.showSearch && (
        <div className="absolute left-1/2 top-[66px] z-[70] flex w-[min(680px,calc(100vw-32px))] -translate-x-1/2 items-center gap-2 rounded-2xl border border-slate-200 bg-white px-3 py-2 shadow-2xl dark:border-slate-800 dark:bg-slate-900">
          <Search className="h-4 w-4 shrink-0 text-slate-400" />
          <input
            autoFocus
            value={props.searchQuery}
            onChange={(event) => props.onSearch(event.target.value)}
            placeholder="Search in document…"
            className="h-8 min-w-0 flex-1 bg-transparent text-sm text-slate-900 outline-none dark:text-white"
          />
          {props.searching && (
            <Loader2 className="h-4 w-4 animate-spin text-slate-400" />
          )}
          {!props.searching && props.searchQuery && (
            <span className="shrink-0 text-xs text-slate-400">
              {props.searchResults.length
                ? `${props.searchActiveIdx + 1} / ${props.searchResults.length}`
                : "No results"}
            </span>
          )}
          <button
            type="button"
            onClick={() => props.onSearchJump(props.searchActiveIdx - 1)}
            disabled={!props.searchResults.length}
            className="grid h-7 w-7 place-items-center rounded-lg hover:bg-slate-100 disabled:opacity-30 dark:hover:bg-slate-800"
            title="Previous result"
          >
            <ArrowUp className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={() => props.onSearchJump(props.searchActiveIdx + 1)}
            disabled={!props.searchResults.length}
            className="grid h-7 w-7 place-items-center rounded-lg hover:bg-slate-100 disabled:opacity-30 dark:hover:bg-slate-800"
            title="Next result"
          >
            <ArrowDown className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            onClick={props.onSearchClose}
            className="grid h-7 w-7 place-items-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
            title="Close search"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Main horizontal tool rail */}
      <nav className="relative z-40 shrink-0 border-b border-slate-200/80 bg-white/95 px-3 py-1.5 shadow-sm backdrop-blur-xl dark:border-slate-800/80 dark:bg-slate-950/95">
        <div className="flex min-w-0 items-center gap-0.5 overflow-x-auto">
          <ToolButton
            icon={<MousePointer2 />}
            label="Select"
            active={toolClass("select")}
            onClick={() => {
              props.onSetActiveTool("select");
            }}
          />
          <ToolButton
            icon={<Hand />}
            label="Hand"
            active={toolClass("hand")}
            onClick={() => {
              props.onSetActiveTool("hand");
            }}
          />
          <Divider />
          <ToolButton
            icon={<Type />}
            label="Text"
            active={toolClass("text") || !!props.editingTextId}
            disabled={props.annotateDisabled}
            onClick={() => props.onSetActiveTool("text")}
          />
          <ToolButton
            icon={<ImageIcon />}
            label="Image"
            active={toolClass("image")}
            disabled={props.annotateDisabled}
            onClick={props.onOpenImage}
          />
          <ToolButton
            icon={<PenLine />}
            label="Draw"
            active={toolClass("draw")}
            disabled={props.annotateDisabled}
            onClick={() => props.onSetActiveTool("draw")}
          />
          <ToolButton
            icon={<Highlighter />}
            label="Highlight"
            active={toolClass("highlight")}
            disabled={props.annotateDisabled}
            onClick={() => props.onSetActiveTool("highlight")}
          />

          <div data-toolbar-popover className="relative shrink-0">
            <ToolButton
              icon={props.activeTool.startsWith("shape-") ? <Square /> : <Square />}
              label="Shapes"
              active={shapeOpen || props.activeTool.startsWith("shape-")}
              disabled={props.annotateDisabled}
              onClick={() => {
                setShapeOpen((open) => !open);
                setMoreOpen(false);
              }}
            />
            {shapeOpen && (
              <div
                data-toolbar-popover
                className="absolute left-0 top-11 z-[100] grid w-56 grid-cols-2 gap-1 rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl dark:border-slate-800 dark:bg-slate-900"
              >
                {shapeTools.map((shape) => (
                  <button
                    key={shape.tool}
                    type="button"
                    onClick={() => {
                      props.onSetActiveShape(shape.tool);
                      props.onSetActiveTool(shape.tool);
                      setShapeOpen(false);
                    }}
                    className="flex items-center gap-2 rounded-xl px-3 py-2 text-left text-xs font-medium text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    <span className="grid h-4 w-4 place-items-center [&>svg]:h-4 [&>svg]:w-4">
                      {shape.icon}
                    </span>
                    {shape.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <ToolButton
            icon={<Eraser />}
            label="Eraser"
            active={toolClass("eraser")}
            disabled={props.annotateDisabled}
            onClick={() => props.onSetActiveTool("eraser")}
          />
          <ToolButton
            icon={<PenTool />}
            label="Signature"
            active={toolClass("signature")}
            disabled={props.annotateDisabled}
            onClick={props.onOpenSignature}
          />

          <div data-toolbar-popover className="relative shrink-0">
            <ToolButton
              icon={<MoreHorizontal />}
              label="More"
              active={moreOpen}
              disabled={props.annotateDisabled}
              onClick={() => {
                setMoreOpen((open) => !open);
                setShapeOpen(false);
              }}
            />
            {moreOpen && (
              <div
                data-toolbar-popover
                className="absolute left-0 top-11 z-[100] w-60 rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl dark:border-slate-800 dark:bg-slate-900"
              >
                {[
                  ["whiteout", "Whiteout"],
                  ["sticky", "Sticky note"],
                  ["field-text", "Text field"],
                  ["field-checkbox", "Checkbox"],
                  ["field-radio", "Radio button"],
                  ["field-dropdown", "Dropdown"],
                ].map(([tool, label]) => (
                  <button
                    key={tool}
                    type="button"
                    onClick={() => {
                      props.onSetActiveTool(tool as Tool);
                      setMoreOpen(false);
                    }}
                    className="flex w-full items-center rounded-xl px-3 py-2 text-left text-xs font-medium text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}
          </div>

          <Divider />
          <ToolButton
            icon={<Layers />}
            label="Pages"
            active={props.showPagePanel}
            onClick={props.onTogglePagePanel}
          />

          <div className="ml-auto hidden shrink-0 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-2.5 py-1 dark:border-slate-800 dark:bg-slate-900/80 md:flex">
            <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
              Page
            </span>
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
              {props.current + 1}/{props.pages.length}
            </span>
          </div>
        </div>
      </nav>

      {/* Tool settings stay at the top, immediately below the horizontal tool rail. */}
      {(props.activeTool === "draw" ||
        props.activeTool === "eraser" ||
        props.activeTool === "highlight" ||
        props.activeTool.startsWith("shape-")) && (
        <div className="relative z-30 shrink-0 border-b border-slate-200/70 bg-white/90 px-3 py-1.5 backdrop-blur dark:border-slate-800/70 dark:bg-slate-950/90">
          <div className="mx-auto flex max-w-[1100px] flex-wrap items-center justify-center gap-2 rounded-2xl border border-slate-200 bg-slate-50/80 p-1.5 shadow-sm dark:border-slate-800 dark:bg-slate-900/70">
            {props.activeTool === "draw" && (
              <>
                <span className="px-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Brush
                </span>
                {[1, 2, 4, 8, 12, 20].map((width) => (
                  <button
                    key={width}
                    type="button"
                    title={`${width}px brush`}
                    onClick={() =>
                      props.setDrawStroke({
                        ...props.drawStroke,
                        width,
                      })
                    }
                    className={cn(
                      "grid h-8 w-8 place-items-center rounded-lg hover:bg-white dark:hover:bg-slate-800",
                      props.drawStroke.width === width &&
                        "bg-white text-[#DC2626] shadow-sm dark:bg-slate-800 dark:text-red-300",
                    )}
                  >
                    <span
                      className="rounded-full bg-current"
                      style={{
                        width: Math.min(18, width),
                        height: Math.min(18, width),
                      }}
                    />
                  </button>
                ))}
                <input
                  type="color"
                  value={props.drawStroke.color}
                  onChange={(event) =>
                    props.setDrawStroke({
                      ...props.drawStroke,
                      color: event.target.value,
                    })
                  }
                  className="h-8 w-8 cursor-pointer rounded-lg border border-slate-200 p-1 dark:border-slate-700"
                  title="Brush color"
                />
              </>
            )}

            {props.activeTool === "eraser" && (
              <>
                <span className="px-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Eraser
                </span>
                {[5, 10, 15, 20, 30, 40, 60].map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => props.setEraserSize(size)}
                    className={cn(
                      "rounded-lg px-2.5 py-1.5 text-[10px] font-medium hover:bg-white dark:hover:bg-slate-800",
                      props.eraserSize === size &&
                        "bg-white text-[#DC2626] shadow-sm dark:bg-slate-800 dark:text-red-300",
                    )}
                  >
                    {size}
                  </button>
                ))}
              </>
            )}

            {props.activeTool === "highlight" && (
              <>
                <span className="px-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Highlight
                </span>
                <input
                  type="color"
                  value={props.highlightSettings.color}
                  onChange={(event) =>
                    props.setHighlightSettings({
                      ...props.highlightSettings,
                      color: event.target.value,
                    })
                  }
                  className="h-8 w-8 cursor-pointer rounded-lg border border-slate-200 p-1 dark:border-slate-700"
                  title="Highlight color"
                />
                <select
                  value={props.highlightSettings.opacity}
                  onChange={(event) =>
                    props.setHighlightSettings({
                      ...props.highlightSettings,
                      opacity: Number(event.target.value),
                    })
                  }
                  className="h-8 rounded-lg border border-slate-200 bg-transparent px-2 text-xs dark:border-slate-700"
                >
                  <option value={0.2}>20%</option>
                  <option value={0.35}>35%</option>
                  <option value={0.5}>50%</option>
                  <option value={0.65}>65%</option>
                </select>
              </>
            )}

            {props.activeTool.startsWith("shape-") && (
              <>
                <span className="px-2 text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                  Shape
                </span>
                <input
                  type="color"
                  value={props.shapeDefaults.stroke}
                  onChange={(event) =>
                    props.setShapeDefaults({
                      ...props.shapeDefaults,
                      stroke: event.target.value,
                    })
                  }
                  className="h-8 w-8 cursor-pointer rounded-lg border border-slate-200 p-1 dark:border-slate-700"
                  title="Stroke color"
                />
                <input
                  type="number"
                  min={1}
                  max={40}
                  value={props.shapeDefaults.strokeWidth}
                  onChange={(event) =>
                    props.setShapeDefaults({
                      ...props.shapeDefaults,
                      strokeWidth: Math.max(
                        1,
                        Number(event.target.value) || 1,
                      ),
                    })
                  }
                  className="h-8 w-14 rounded-lg border border-slate-200 bg-transparent px-2 text-xs dark:border-slate-700"
                  title="Stroke width"
                />
                <select
                  value={props.shapeDefaults.dash}
                  onChange={(event) =>
                    props.setShapeDefaults({
                      ...props.shapeDefaults,
                      dash: event.target.value as Props["shapeDefaults"]["dash"],
                    })
                  }
                  className="h-8 rounded-lg border border-slate-200 bg-transparent px-2 text-xs dark:border-slate-700"
                >
                  <option value="solid">Solid</option>
                  <option value="dashed">Dashed</option>
                  <option value="dotted">Dotted</option>
                </select>
                <button
                  type="button"
                  onClick={() =>
                    props.setShapeDefaults({
                      ...props.shapeDefaults,
                      fill:
                        props.shapeDefaults.fill === null
                          ? "#ffffff"
                          : null,
                    })
                  }
                  className={cn(
                    "rounded-lg px-2.5 py-1.5 text-[10px] font-medium",
                    props.shapeDefaults.fill === null
                      ? "hover:bg-white dark:hover:bg-slate-800"
                      : "bg-white text-[#DC2626] shadow-sm dark:bg-slate-800 dark:text-red-300",
                  )}
                >
                  {props.shapeDefaults.fill === null ? "No fill" : "Fill"}
                </button>
                <input
                  type="color"
                  disabled={props.shapeDefaults.fill === null}
                  value={props.shapeDefaults.fill ?? "#ffffff"}
                  onChange={(event) =>
                    props.setShapeDefaults({
                      ...props.shapeDefaults,
                      fill: event.target.value,
                    })
                  }
                  className="h-8 w-8 cursor-pointer rounded-lg border border-slate-200 p-1 disabled:cursor-not-allowed disabled:opacity-40 dark:border-slate-700"
                  title="Fill color"
                />
              </>
            )}
          </div>
        </div>
      )}

      {props.showPagePanel && (
        <div className="absolute bottom-4 left-4 top-[116px] z-30 w-56 overflow-hidden rounded-2xl border border-slate-200 bg-white/95 shadow-xl backdrop-blur dark:border-slate-800 dark:bg-slate-900/95">
          <div className="flex items-center justify-between border-b border-slate-200 px-3 py-2 dark:border-slate-800">
            <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
              Pages
            </span>
            <span className="text-[10px] text-slate-400">
              {props.current + 1}/{props.pages.length}
            </span>
          </div>
          <div className="h-full overflow-auto p-2 pb-16">
            {props.pages.map((page, index) => (
              <div
                key={page.id}
                className={cn(
                  "mb-2 rounded-xl border p-1.5",
                  props.current === index
                    ? "border-red-300 bg-red-50/60 dark:border-red-500/50 dark:bg-red-500/10"
                    : "border-slate-200 dark:border-slate-800",
                )}
              >
                <button
                  type="button"
                  onClick={() => props.onPageClick(index)}
                  className="block w-full rounded-lg bg-slate-100 p-1 dark:bg-slate-800"
                >
                  {props.thumbs[index] ? (
                    <img
                      src={props.thumbs[index]}
                      alt={`Page ${index + 1}`}
                      className="mx-auto max-h-36 w-full object-contain"
                    />
                  ) : (
                    <div className="grid aspect-[3/4] place-items-center text-[10px] text-slate-400">
                      Blank page
                    </div>
                  )}
                </button>
                <div className="mt-1 flex items-center justify-between gap-1 text-[10px] text-slate-400">
                  <span>Page {index + 1}</span>
                  <div className="flex gap-0.5">
                    <button
                      title="Move up"
                      type="button"
                      disabled={index === 0}
                      onClick={() => props.onMovePage(index, index - 1)}
                      className="rounded p-1 hover:bg-slate-100 disabled:opacity-30 dark:hover:bg-slate-800"
                    >
                      <ArrowUp className="h-3 w-3" />
                    </button>
                    <button
                      title="Move down"
                      type="button"
                      disabled={index === props.pages.length - 1}
                      onClick={() => props.onMovePage(index, index + 1)}
                      className="rounded p-1 hover:bg-slate-100 disabled:opacity-30 dark:hover:bg-slate-800"
                    >
                      <ArrowDown className="h-3 w-3" />
                    </button>
                    <button
                      title="Rotate"
                      type="button"
                      onClick={() => props.onRotatePage(index, 90)}
                      className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <RotateCw className="h-3 w-3" />
                    </button>
                    <button
                      title="Duplicate"
                      type="button"
                      onClick={() => props.onDuplicatePage(index)}
                      className="rounded p-1 hover:bg-slate-100 dark:hover:bg-slate-800"
                    >
                      <Copy className="h-3 w-3" />
                    </button>
                    <button
                      title="Delete"
                      type="button"
                      onClick={() => props.onDeletePage(index)}
                      className="rounded p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            <button
              type="button"
              onClick={() => props.onInsertBlankPage(props.current)}
              className="w-full rounded-xl border border-dashed border-slate-300 py-2 text-xs font-medium text-slate-500 hover:bg-slate-50 dark:border-slate-700 dark:hover:bg-slate-800"
            >
              + Blank page
            </button>
          </div>
        </div>
      )}

      {contextual && (
        <div
          className="pointer-events-auto fixed z-[80]"
          style={{
            left: contextual.left,
            top: contextual.top,
            width: contextual.width,
          }}
        >
          <div
            className="flex flex-wrap items-center gap-1.5 rounded-2xl border border-slate-200 bg-white/95 p-2 shadow-2xl backdrop-blur dark:border-slate-700 dark:bg-slate-900/95"
            onPointerDown={(event) => event.stopPropagation()}
          >
            {multi && (
              <span className="px-2 text-xs font-semibold text-slate-500">
                {props.selectedElements.length} selected
              </span>
            )}

            {single && (
              <>
                <div className="flex items-center gap-1 rounded-xl border border-slate-200 px-1 py-1 dark:border-slate-700">
                  <button
                    type="button"
                    onClick={props.onDuplicate}
                    className="grid h-7 w-7 place-items-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="Duplicate"
                  >
                    <Copy className="h-3.5 w-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={props.onDelete}
                    className="grid h-7 w-7 place-items-center rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"
                    title="Delete"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
                <Divider />
                <label className="flex h-8 items-center gap-1 rounded-xl border border-slate-200 px-2 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400">W</span>
                  <input
                    type="number"
                    min={16}
                    value={Math.round(single.width)}
                    onChange={(event) =>
                      props.onUpdateElement(single.id, {
                        width: Math.max(16, Number(event.target.value) || 16),
                      })
                    }
                    className="w-14 bg-transparent text-xs outline-none"
                  />
                </label>
                <label className="flex h-8 items-center gap-1 rounded-xl border border-slate-200 px-2 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400">H</span>
                  <input
                    type="number"
                    min={16}
                    value={Math.round(single.height)}
                    onChange={(event) =>
                      props.onUpdateElement(single.id, {
                        height: Math.max(16, Number(event.target.value) || 16),
                      })
                    }
                    className="w-14 bg-transparent text-xs outline-none"
                  />
                </label>
                <label className="flex h-8 items-center gap-1 rounded-xl border border-slate-200 px-2 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400">O</span>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={Math.round(single.opacity * 100)}
                    onChange={(event) =>
                      props.onUpdateElement(single.id, {
                        opacity: Math.max(
                          0,
                          Math.min(1, Number(event.target.value) / 100),
                        ),
                      })
                    }
                    className="w-10 bg-transparent text-xs outline-none"
                  />
                </label>
                <button
                  type="button"
                  onClick={() =>
                    props.onUpdateElement(single.id, {
                      rotation: (single.rotation + 15) % 360,
                    })
                  }
                  className="grid h-8 w-8 place-items-center rounded-xl border border-slate-200 hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
                  title="Rotate 15°"
                >
                  <RotateCw className="h-3.5 w-3.5" />
                </button>
              </>
            )}

            {multi && (
              <div className="flex items-center gap-1 rounded-xl border border-slate-200 p-1 dark:border-slate-700">
                <button
                  title="Align left"
                  type="button"
                  onClick={() => props.onAlign("left")}
                  className="grid h-7 w-7 place-items-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <AlignLeft className="h-3.5 w-3.5" />
                </button>
                <button
                  title="Align center"
                  type="button"
                  onClick={() => props.onAlign("center")}
                  className="grid h-7 w-7 place-items-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <AlignCenter className="h-3.5 w-3.5" />
                </button>
                <button
                  title="Align right"
                  type="button"
                  onClick={() => props.onAlign("right")}
                  className="grid h-7 w-7 place-items-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <AlignRight className="h-3.5 w-3.5" />
                </button>
                <button
                  title="Distribute"
                  type="button"
                  onClick={() => props.onDistribute("horizontal")}
                  className="grid h-7 w-7 place-items-center rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <AlignHorizontalDistributeCenter className="h-3.5 w-3.5" />
                </button>
              </div>
            )}

            {selectedText && (
              <>
                <Divider />
                <select
                  value={selectedText.font}
                  onChange={(event) =>
                    props.onLoadCustomFont(selectedText.id, event.target.value)
                  }
                  className="h-8 max-w-[170px] rounded-xl border border-slate-200 bg-transparent px-2 text-xs outline-none dark:border-slate-700"
                  style={{ fontFamily: selectedText.font }}
                >
                  {FONT_OPTIONS.map((font) => (
                    <option key={font} value={font}>
                      {font}
                    </option>
                  ))}
                  <optgroup label="Google Fonts">
                    {GOOGLE_FONTS.map((font) => (
                      <option key={font} value={font}>
                        {font}
                      </option>
                    ))}
                  </optgroup>
                </select>
                <input
                  type="number"
                  min={6}
                  max={120}
                  value={selectedText.fontSize}
                  onChange={(event) =>
                    props.onUpdateElement(selectedText.id, {
                      fontSize: Math.max(
                        6,
                        Math.min(120, Number(event.target.value) || 14),
                      ),
                    })
                  }
                  className="h-8 w-14 rounded-xl border border-slate-200 bg-transparent px-2 text-xs dark:border-slate-700"
                  title="Font size"
                />
                <button
                  type="button"
                  onClick={() =>
                    props.onUpdateElement(selectedText.id, {
                      bold: !selectedText.bold,
                    })
                  }
                  className={cn(
                    "grid h-8 w-8 place-items-center rounded-xl",
                    selectedText.bold
                      ? "bg-red-50 text-[#DC2626] dark:bg-red-500/15"
                      : "hover:bg-slate-100 dark:hover:bg-slate-800",
                  )}
                  title="Bold"
                >
                  <Bold className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    props.onUpdateElement(selectedText.id, {
                      italic: !selectedText.italic,
                    })
                  }
                  className={cn(
                    "grid h-8 w-8 place-items-center rounded-xl",
                    selectedText.italic
                      ? "bg-red-50 text-[#DC2626] dark:bg-red-500/15"
                      : "hover:bg-slate-100 dark:hover:bg-slate-800",
                  )}
                  title="Italic"
                >
                  <Italic className="h-3.5 w-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    props.onUpdateElement(selectedText.id, {
                      underline: !selectedText.underline,
                    })
                  }
                  className={cn(
                    "grid h-8 w-8 place-items-center rounded-xl",
                    selectedText.underline
                      ? "bg-red-50 text-[#DC2626] dark:bg-red-500/15"
                      : "hover:bg-slate-100 dark:hover:bg-slate-800",
                  )}
                  title="Underline"
                >
                  <Underline className="h-3.5 w-3.5" />
                </button>
                <div className="flex items-center gap-0.5 rounded-xl border border-slate-200 p-1 dark:border-slate-700">
                  <button
                    type="button"
                    onClick={() =>
                      props.onUpdateElement(selectedText.id, { align: "left" })
                    }
                    className="grid h-6 w-6 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="Align left"
                  >
                    <AlignLeft className="h-3 w-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      props.onUpdateElement(selectedText.id, { align: "center" })
                    }
                    className="grid h-6 w-6 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="Align center"
                  >
                    <AlignCenter className="h-3 w-3" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      props.onUpdateElement(selectedText.id, { align: "right" })
                    }
                    className="grid h-6 w-6 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
                    title="Align right"
                  >
                    <AlignRight className="h-3 w-3" />
                  </button>
                </div>
                <input
                  type="color"
                  value={selectedText.color}
                  onChange={(event) =>
                    props.onUpdateElement(selectedText.id, {
                      color: event.target.value,
                    })
                  }
                  className="h-8 w-8 cursor-pointer rounded-xl border border-slate-200 p-1 dark:border-slate-700"
                  title="Text color"
                />
              </>
            )}

            {selectedShape && (
              <>
                <input
                  type="color"
                  value={selectedShape.stroke}
                  onChange={(event) =>
                    props.onUpdateElement(selectedShape.id, {
                      stroke: event.target.value,
                    })
                  }
                  className="h-8 w-8 cursor-pointer rounded-xl border border-slate-200 p-1 dark:border-slate-700"
                  title="Stroke"
                />
                <input
                  type="number"
                  min={1}
                  max={40}
                  value={selectedShape.strokeWidth}
                  onChange={(event) =>
                    props.onUpdateElement(selectedShape.id, {
                      strokeWidth: Math.max(
                        1,
                        Math.min(40, Number(event.target.value) || 1),
                      ),
                    })
                  }
                  className="h-8 w-14 rounded-xl border border-slate-200 bg-transparent px-2 text-xs dark:border-slate-700"
                  title="Stroke width"
                />
                {![
                  "line",
                  "arrow",
                ].includes(selectedShape.type) && (
                  <input
                    type="color"
                    value={selectedShape.fill ?? "#ffffff"}
                    onChange={(event) =>
                      props.onUpdateElement(selectedShape.id, {
                        fill: event.target.value,
                      })
                    }
                    className="h-8 w-8 cursor-pointer rounded-xl border border-slate-200 p-1 dark:border-slate-700"
                    title="Fill"
                  />
                )}
                <select
                  value={selectedShape.dash ?? "solid"}
                  onChange={(event) =>
                    props.onUpdateElement(selectedShape.id, {
                      dash: event.target.value as ShapeElement["dash"],
                    })
                  }
                  className="h-8 rounded-xl border border-slate-200 bg-transparent px-2 text-xs dark:border-slate-700"
                >
                  <option value="solid">Solid</option>
                  <option value="dashed">Dashed</option>
                  <option value="dotted">Dotted</option>
                </select>
              </>
            )}

            {selectedImage && (
              <button
                type="button"
                onClick={props.onOpenImageForSelected}
                className="inline-flex h-8 items-center gap-1 rounded-xl border border-slate-200 px-2 text-xs font-medium hover:bg-slate-100 dark:border-slate-700 dark:hover:bg-slate-800"
              >
                <ImageIcon className="h-3.5 w-3.5" />
                Replace
              </button>
            )}

            {single && (
              <div className="ml-auto flex items-center gap-1 rounded-xl border border-slate-200 p-1 dark:border-slate-700">
                <button
                  type="button"
                  title="Bring forward"
                  onClick={() => props.onReorder("forward")}
                  className="grid h-6 w-6 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <ArrowUp className="h-3 w-3" />
                </button>
                <button
                  type="button"
                  title="Send backward"
                  onClick={() => props.onReorder("backward")}
                  className="grid h-6 w-6 place-items-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  <ArrowDown className="h-3 w-3" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
